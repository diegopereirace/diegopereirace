<?php

namespace Drupal\user;

use Drupal\Core\Flood\FloodInterface;

/**
 * Defines an interface for user flood controllers.
 */
interface UserFloodControlInterface extends FloodInterface {

}
